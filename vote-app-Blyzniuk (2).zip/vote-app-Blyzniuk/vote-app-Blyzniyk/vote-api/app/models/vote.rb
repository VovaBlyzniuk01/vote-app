class Vote < ApplicationRecord
  belongs_to :poll
end
